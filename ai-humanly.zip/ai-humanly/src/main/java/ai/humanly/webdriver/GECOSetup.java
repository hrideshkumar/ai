package ai.humanly.webdriver;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;



@Component
//@Scope("singleton")
@Scope(value = "singleton")
public class GECOSetup {



	// String webDriverPath;
	volatile WebDriver driver = null;

	
	String osType = "";
	
	

	public WebDriver getWebDriver() {
		
		osType = System.getProperty("os.name");
		String driverPath = null;
		if (osType.contains("Windows")) {
			driverPath = new
					 File(getClass().getClassLoader().getResource("geckodriver.exe").getFile()).getAbsolutePath();
			// driverFile = new
			// File(getClass().getClassLoader().getResource("gecodriver/geckodriver.exe").getFile());
		} else if (osType.contains("Linux")) {
			// driverFile = new
			// File(getClass().getClassLoader().getResource("gecodriver/geckodriver").getFile());
			driverPath = new
					File(getClass().getClassLoader().getResource("webdriver").getFile()).getAbsolutePath();
			
			
		}

		// File file = new File(webDriverPath);
		// System.out.println("Driver Path :::: "+file.getAbsolutePath());
		
		// System.out.println("Driver path::: "+driverPath);
		System.setProperty("webdriver.gecko.driver", driverPath);

		System.setProperty(FirefoxDriver.SystemProperty.DRIVER_USE_MARIONETTE, "true");
		System.setProperty(FirefoxDriver.SystemProperty.BROWSER_LOGFILE, "/dev/null");

		// System.setProperty(FirefoxDriver.SystemProperty.DRIVER_USE_MARIONETTE,"true");
		//System.out.println("Driver launch ->>> "+driver);
		if (driver == null) {
			synchronized (GECOSetup.class) {
				if (driver == null) {
					try {

						//System.out.println("Intilization: Driver object.");
						
						FirefoxProfile profile = new FirefoxProfile();
						// profile.setPreference("browser.download.dir",
						// "D:/work/HelloVerify/codebase/cts-screeshot/"); // folder

						
						// profile.setPreference("browser.helperApps.neverAsk.saveToDisk",
						// "application/pdf"); // MIME type
						profile.setPreference("pdfjs.disabled", true); // disable the built-in viewer
						profile.setPreference("browser.download.folderList", 2);
						profile.setPreference("browser.download.panel.shown", false);

						profile.setPreference("browser.download.manager.alertOnEXEOpen", false);

						/*
						 * profile.setPreference("browser.helperApps.neverAsk.saveToDisk",
						 * "application/xls, application/msword, application/csv, application/ris, text/csv, image/png, application/pdf, "
						 * +
						 * "text/html, text/plain, application/zip, application/x-zip, application/x-zip-compressed, "
						 * +
						 * "application/download, application/octet-stream, application/json, application/vnd.ms-excel, text/csv"
						 * + "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;");
						 * 
						 * profile.setPreference("browser.helperApps.neverAsk.openFile",
						 * "application/xls");
						 */

						profile.setPreference("browser.helperApps.neverAsk.saveToDisk",
								"application/msword, application/csv, application/ris, text/csv, image/png, application/pdf, text/html, text/plain, application/zip, application/x-zip, application/x-zip-compressed, application/download, application/octet-stream");

						profile.setPreference("browser.download.manager.showWhenStarting", false);
						profile.setPreference("browser.download.manager.focusWhenStarting", false);
						profile.setPreference("browser.download.useDownloadDir", true);
						profile.setPreference("browser.helperApps.alwaysAsk.force", false);
						profile.setPreference("browser.download.manager.alertOnEXEOpen", false);
						profile.setPreference("browser.download.manager.closeWhenDone", true);
						profile.setPreference("browser.download.manager.showAlertOnComplete", false);
						profile.setPreference("browser.download.manager.useWindow", false);
						profile.setPreference("services.sync.prefs.sync.browser.download.manager.showWhenStarting",
								false);
						profile.setPreference("pdfjs.disabled", true);

						FirefoxOptions options = new FirefoxOptions();
						options.setProfile(profile);

						

						if (osType.contains("Linux")) {
							options.addArguments("--headless");
						}

						driver = new FirefoxDriver(options);
						driver.manage().window().maximize();

						// DesiredCapabilities capabilities = DesiredCapabilities.firefox();
						// capabilities.setCapability(FirefoxDriver.PROFILE, profile);
						// capabilities.setCapability(CapabilityType.ELEMENT_SCROLL_BEHAVIOR, 1);

						// driver = new FirefoxDriver(capabilities);

						return driver;

					} catch (Exception e) {
						System.err.println("Driver launch error::: " + e);
					}

				}
			}

		}

		return driver;
	}

	public void shutdownGecoDriver() {
		try {
			driver = null;
			if (osType.contains("Windows")) {
				Runtime.getRuntime().exec("taskkill /F /IM geckodriver.exe /T");
			} else if (osType.contains("Linux")) {
				Runtime.getRuntime()
						.exec("ps -ef | grep 'geckodriver' | grep -v grep | awk '{print $2}' | xargs -r kill -9");
			}

			/*
			 * ProcessBuilder builder = new ProcessBuilder(); if(osType.contains("Windows"))
			 * { builder.command("cmd.exe", "/c", "taskkill /F /IM geckodriver.exe /T");
			 * }else if(osType.contains("Linux")) { builder.command("sh", "-c",
			 * "ps -ef | grep 'geckodriver' | grep -v grep | awk '{print $2}' | xargs -r kill -9"
			 * ); } builder.directory(new File(System.getProperty("user.home"))); Process
			 * process = builder.start(); StreamGobbler streamGobbler = new
			 * StreamGobbler(process.getInputStream(), System.out::println);
			 * //Executors.newSingleThreadExecutor().submit(streamGobbler); //int exitCode =
			 * process.waitFor();
			 * //System.out.println("Closed gecodriver  with exit code: "+exitCode);
			 * 
			 * BufferedReader buf = new BufferedReader(new InputStreamReader(
			 * process.getInputStream())); String[] processID = new
			 * String[buf.readLine().length()];
			 * 
			 * for (int count = 0; count < processID.length; count++) { processID[count] =
			 * buf.readLine(); } for (int count = 0; count < processID.length; count++) {
			 * System.out.println("processIDs ::: "+processID[count]); }
			 */

		} catch (Exception e) {
		}

	}

	public boolean isGECORunning() {
		System.out.println("Checking: geco Running status");
		boolean isRunning = Boolean.FALSE;
		osType = System.getProperty("os.name");
		try {
			String line;
			if (osType.contains("Windows")) {
				
				String pidInfo = "";

				Process p = Runtime.getRuntime().exec(System.getenv("windir") + "/system32/" + "tasklist.exe");
				
				BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
				
				while ((line = input.readLine()) != null) {
					pidInfo += line;
				}
				input.close();
				if (pidInfo.contains("geckodriver.exe")) {
					System.out.println("Alredy running geco");
					isRunning = true;
				} else {
					System.out.println("not running running geco");
				}
			} else if (osType.contains("Linux")) {
				Process p = Runtime.getRuntime().exec("pidof geckodriver");
				BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
				while ((line = input.readLine()) != null)
			      {
			        String[] processArray = line.split(" ");
			        
			        if(processArray.length > 0) {
			        	System.out.println("Alredy running geco");
			        	System.out.println("**** list of geco process *******");
			        	for (int i = 0; i < processArray.length; i++) {
							System.out.println("PID:: "+processArray[i]);
						}
						isRunning = true;
			        }else {
			        	System.out.println("not running running geco");
			        }
			        		
			        
			      }
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Checked: geco Running status is "+isRunning);
		return isRunning;
	}

}
