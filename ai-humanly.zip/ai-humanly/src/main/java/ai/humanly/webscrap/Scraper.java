package ai.humanly.webscrap;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ai.humanly.webdriver.GECOSetup;

@Component
public class Scraper {

	@Autowired
	GECOSetup gecoDriver;
	
	
	public String doBrowse(String para, String que) {
		String result = "";
		
		
		
		WebElement element = null;

		WebDriver driver = gecoDriver.getWebDriver();
		System.out.println("Driver Obj in Sc: "+driver);
		try {
			if(driver != null) {
				driver.navigate().to("http://humanly.ai/");

				new WebDriverWait(driver, 100).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/div/form/div[1]/textarea")));
				element = driver.findElement(By.xpath("/html/body/div[2]/div/form/div[1]/textarea"));
				element.sendKeys(para);
				
				
				new WebDriverWait(driver, 100).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"question\"]")));
				element = driver.findElement(By.xpath("//*[@id=\"question\"]"));
				element.sendKeys(que);
				
				// 
				element = driver.findElement(By.xpath("/html/body/div[2]/div/form/div[2]/div[2]/input"));
				element.click();
				
				
				try {
					new WebDriverWait(driver, 100).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"answerTxt\"]")));
					element = driver.findElement(By.xpath("//*[@id=\"answerTxt\"]"));
					result = element.getText();
					return result;
				} catch (NoSuchElementException e) {
					
				}
				
				
				new WebDriverWait(driver, 100).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/div/form/div[2]/div[5]")));
				element = driver.findElement(By.xpath("/html/body/div[2]/div/form/div[2]/div[5]"));
				
				result = element.getText();
				return result;
				
				/*
				//failer case // /html/body/div[2]/div/form/div[2]/div[5]
				element = driver.findElement(By.xpath(""));
				element.sendKeys(para);*/
			}
		} catch (Exception e) {
			System.err.println(e);
		}
		return result;
	}
	
	public void closeBrowser() {
		gecoDriver.shutdownGecoDriver();
	}
}
