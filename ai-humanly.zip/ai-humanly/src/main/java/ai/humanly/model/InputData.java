package ai.humanly.model;


public class InputData {

	private String para;
	private String que;
	
	public String getPara() {
		return para;
	}
	public void setPara(String para) {
		this.para = para;
	}
	public String getQue() {
		return que;
	}
	public void setQue(String que) {
		this.que = que;
	}
	
	@Override
	public String toString() {
		return "InputData [para=" + para + ", que=" + que + "]";
	}
	
	
	
}
