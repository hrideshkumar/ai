package ai.humanly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiHumanlyApplication {

	public static void main(String[] args) {
		
		
		//ApplicationContext context =  
				SpringApplication.run(AiHumanlyApplication.class, args);
		
		
		//Scraper controller = (Scraper)context.getBean(Scraper.class);
		//String r = controller.doBrowse("para", "que");
		
		//System.out.println("Result ::: "+r);
	}

}

