package ai.humanly.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ai.humanly.model.InputData;
import ai.humanly.webscrap.Scraper;

@RestController
@RequestMapping(value = "/ai")
public class ApiController {

	@Autowired
	Scraper scraper;
	
	@RequestMapping(value = "/startChat", method = RequestMethod.POST)
	public String chatConversation(@RequestBody InputData request) {
		System.out.println("Input Data ::: "+request);
		return scraper.doBrowse(request.getPara(), request.getQue());
	}
	
	
	@RequestMapping(value = "/endChat", method = RequestMethod.GET)
	public String endChatConversation() {
		scraper.closeBrowser();
		return "OK";
	}
	
}
